from vue import log_vue


if __name__ == "__main__":
    app = log_vue.SampleApp()
    app.mainloop()