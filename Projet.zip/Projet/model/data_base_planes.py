import mysql.connector

def check_DB_exists():
    
    #Try to connect to the server
    try:
        connexion=mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="",
            )   
    except Exception as e:
        print (e)
        connexion.close()

    #Create a cursor
    connexion_curseur=connexion.cursor()
    
    #Looking for if the DB has already been created
    existante=False
    #If the connection is set
    if (connexion.is_connected()):
        #Looking for the DB
        connexion_curseur.execute("SHOW DATABASES")
        for x in connexion_curseur:
            if(x==('projetlogiciel',)):
                existante=True
    else:
        print("Connexion lost")
    
    #If the DB is not created
    if(existante==False):
        #If the connection is set
        if (connexion.is_connected()):
            #Create the DB
            try:
                connexion_curseur.execute("CREATE DATABASE projetLogiciel")
                connexion.connect(
                                    database='projetlogiciel'
                                    )       
            except Exception as e:
                print (e)
        else:
            print("Connexion lost")
    
        #Create tables
        if (connexion.is_connected()):
            try:
                connexion_curseur.execute("CREATE TABLE `projetlogiciel`.`people` ( `Name` VARCHAR(100) NOT NULL , `Surname` VARCHAR(100) NOT NULL , `Address` VARCHAR(100) NOT NULL , `Balance` FLOAT NOT NULL, `Username` VARCHAR(100), `Password` VARCHAR(100) , `Admin` BOOLEAN NOT NULL, `Picture` VARCHAR(100) NOT NULL)")
                connexion_curseur.execute("CREATE TABLE `projetlogiciel`.`planes` ( `Immatriculation` VARCHAR(100) NOT NULL , `Model` VARCHAR(100) NOT NULL , `Year` INT NOT NULL , `Hours` FLOAT NOT NULL ,`Price` INT NOT NULL,`Flying` BOOLEAN NOT NULL , `Overhaul` BOOLEAN NOT NULL , `Picture` VARCHAR(100) NOT NULL )")
                connexion_curseur.execute("CREATE TABLE `projetlogiciel`.`deposit` ( `Username` VARCHAR(100) NOT NULL , `Money` FLOAT NOT NULL)")
                connexion_curseur.execute("CREATE TABLE `projetlogiciel`.`Overhaul` ( `Plane` VARCHAR(100) NOT NULL , `Money` FLOAT NOT NULL)")
                connexion_curseur.execute("CREATE TABLE `projetlogiciel`.`Flights` ( `Plane` VARCHAR(100) NOT NULL ,`Username` VARCHAR(100) NOT NULL , `Price` FLOAT NOT NULL)")
                connexion_curseur.execute("CREATE TABLE `projetlogiciel`.`Flying` ( `Plane` VARCHAR(100) NOT NULL ,`Username` VARCHAR(100) NOT NULL)")
                connexion_curseur.execute("INSERT INTO `people` (`Name`, `Surname`, `Address`, `Balance`, `Username`, `Password`, `Admin`, `Picture`) VALUES ('Admin', 'Admin', 'Admin', '0', 'Login', 'Password', '1','./res/logo_wait_picture_person.png')")
            except Exception as e:
                print (e)
        else:
            print("Connexion lost")
            
def creationConnection():
    #Try to connect to the server
    try:
        connection=mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="",
            )   
    except Exception as e:
        print (e)
        connection.close()
        
    try:
            connection.connect(
            database='projetlogiciel'
            )
    except Exception as e:
            print (e)
    return connection
            
def credentials_corrects(login,password):
    connection=creationConnection()

    #Creation cursor
    connection_curseur=connection.cursor()
    
    if (connection.is_connected()):
        try:
            sql = "SELECT Password FROM people WHERE Username = %s"
            val = (login,)
            connection_curseur.execute(sql, val)
            resultatFederation=connection_curseur.fetchall()
            
            if (len(resultatFederation)==0):
                return 0
            else:
                if password==resultatFederation[0][0]:
                    return 1
                else:
                    return 0
                    
        except Exception as e:
            print (e)
    else:
        print("Connection lost")
    
    return 0
    
def immatriculaton_not_exists(Immatriculation):
    connection=creationConnection()

    #Creation cursor
    connection_curseur=connection.cursor()
    
    if (connection.is_connected()):
        try:
            sql = "SELECT Immatriculation FROM planes WHERE Immatriculation = %s"
            val = (Immatriculation,)
            connection_curseur.execute(sql, val)
            resultatFederation=connection_curseur.fetchall()
            
            if (len(resultatFederation)==0):
                return 1
            else:
                return 0
                    
        except Exception as e:
            print (e)
    else:
        print("Connection lost")
    
    return 0

def insert_new_plane(Immatriculation,Model,Year,Hours,Price,Overhaul,Picture,Flying):
    connection=creationConnection()

    #Creation cursor
    connection_curseur=connection.cursor()
    
    if (connection.is_connected()):
        try:
            sql = "INSERT INTO `planes` (`Immatriculation`, `Model`, `Year`, `Hours`, `Price`, `Flying`, `Overhaul`, `Picture`) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)"
            val = (Immatriculation,Model,Year,Hours,Price,Flying,Overhaul,Picture)
            connection_curseur.execute(sql, val)
            connection.commit()
        except Exception as e:
            print (e)
    else:
        print("Connection lost")
    
    return 0

#Useless
def get_link_image(Immatriculation):
    connection=creationConnection()

    #Creation cursor
    connection_curseur=connection.cursor()
    
    if (connection.is_connected()):
        try:
            sql = "SELECT Picture FROM planes WHERE Immatriculation = %s"
            val = (Immatriculation,)
            connection_curseur.execute(sql, val)
            resultatFederation=connection_curseur.fetchall()
                    
        except Exception as e:
            print (e)
    else:
        print("Connection lost")
    
    return resultatFederation[0][0]

def modify_plane(Immatriculation,Model,Year,Hours,Price,Overhaul,Picture,Flying):
    connection=creationConnection()

    #Creation cursor
    connection_curseur=connection.cursor()
    
    if (connection.is_connected()):
        try:
            sql = "UPDATE planes SET Model=%s, Year=%s, Hours=%s, Price=%s, Flying=%s, Overhaul=%s WHERE Immatriculation=%s"
            val = (Model,Year,Hours,Price,Flying,Overhaul,Immatriculation)
            connection_curseur.execute(sql, val)
            connection.commit()
                    
        except Exception as e:
            print (e)
    else:
        print("Connection lost")

def delete_plane(Immatriculation):
    connection=creationConnection()

    #Creation cursor
    connection_curseur=connection.cursor()
    
    if (connection.is_connected()):
        try:
            sql = "DELETE FROM planes WHERE Immatriculation=%s"
            val = (Immatriculation,)
            connection_curseur.execute(sql, val)
            connection.commit()
                    
        except Exception as e:
            print (e)
    else:
        print("Connection lost")
    
def select_all_immatriculation():
    connection=creationConnection()

    #Creation cursor
    connection_curseur=connection.cursor()
    
    L=list()
    
    if (connection.is_connected()):
        try:
            sql = "SELECT Immatriculation FROM planes ORDER BY Immatriculation"
            connection_curseur.execute(sql)
            resultatFederation=connection_curseur.fetchall()
                    
        except Exception as e:
            print (e)
    else:
        print("Connection lost")
    if len(resultatFederation)!=0:
        for i in resultatFederation:
            L.append(i[0])
    return L

def get_plane_info(plane):
    connection=creationConnection()

    #Creation cursor
    connection_curseur=connection.cursor()
    
    if (connection.is_connected()):
        try:
            sql = "SELECT * FROM planes WHERE Immatriculation = %s"
            val = (plane,)
            connection_curseur.execute(sql, val)
            resultatFederation=connection_curseur.fetchall()
                    
        except Exception as e:
            print (e)
    else:
        print("Connection lost")
            
    return resultatFederation[0]


def overhaul(Plane,Money):
    connection=creationConnection()

    #Creation cursor
    connection_curseur=connection.cursor()
    
    if (connection.is_connected()):
        try:
            sql = "INSERT INTO `overhaul` (`Plane`, `Money`) VALUES (%s,%s)"
            val = (Plane,Money,)
            connection_curseur.execute(sql, val)
            connection.commit()
        except Exception as e:
            print (e)
    else:
        print("Connection lost")
    return



def pdf_flights():
    connection=creationConnection()

    #Creation cursor
    connection_curseur=connection.cursor()
    
    if (connection.is_connected()):
        try:
            sql = "SELECT * FROM flights"
            connection_curseur.execute(sql)
            resultatFederation=connection_curseur.fetchall()
                    
        except Exception as e:
            print (e)
    else:
        print("Connection lost")
            
    return resultatFederation


def pdf_sum_flights():
    connection=creationConnection()

    #Creation cursor
    connection_curseur=connection.cursor()
    
    if (connection.is_connected()):
        try:
            sql = "SELECT SUM(Price) FROM flights"
            connection_curseur.execute(sql)
            resultatFederation=connection_curseur.fetchall()
                    
        except Exception as e:
            print (e)
    else:
        print("Connection lost")
            
    return str(resultatFederation[0][0])


def pdf_overhauls():
    connection=creationConnection()

    #Creation cursor
    connection_curseur=connection.cursor()
    
    if (connection.is_connected()):
        try:
            sql = "SELECT * FROM overhaul"
            connection_curseur.execute(sql)
            resultatFederation=connection_curseur.fetchall()
                    
        except Exception as e:
            print (e)
    else:
        print("Connection lost")
            
    return resultatFederation


def pdf_sum_overhauls():
    connection=creationConnection()

    #Creation cursor
    connection_curseur=connection.cursor()
    
    if (connection.is_connected()):
        try:
            sql = "SELECT SUM(Money) FROM overhaul"
            connection_curseur.execute(sql)
            resultatFederation=connection_curseur.fetchall()
                    
        except Exception as e:
            print (e)
    else:
        print("Connection lost")
            
    return str(resultatFederation[0][0])