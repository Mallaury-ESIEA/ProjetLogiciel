import mysql.connector
from datetime import date

def creationConnection():
    #Try to connect to the server
    try:
        connection=mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="",
            )   
    except Exception as e:
        print (e)
        connection.close()
        
    try:
            connection.connect(
            database='projetlogiciel'
            )
    except Exception as e:
            print (e)
    return connection

    

def person_not_exists(Username):
    connection=creationConnection()

    #Creation cursor
    connection_curseur=connection.cursor()
    
    if (connection.is_connected()):
        try:
            sql = "SELECT Username FROM people WHERE Username = %s"
            val = (Username,)
            connection_curseur.execute(sql, val)
            results=connection_curseur.fetchall()
            
            if (len(results)==0):
                return 1
            else:
                return 0
                    
        except Exception as e:
            print (e)
    else:
        print("Connection lost")
    
    return 0


def insert_new_person(Name,Surname,Address,Balance,Username,Password,Admin,Picture):
    connection=creationConnection()

    #Creation cursor
    connection_curseur=connection.cursor()
    
    if (connection.is_connected()):
        try:
            sql = "INSERT INTO `people` (`Name`, `Surname`, `Address`, `Balance`, `Username`, `Password`, `Admin`, `Picture`) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)"
            val = (Name,Surname,Address,Balance,Username,Password,Admin,Picture,)
            connection_curseur.execute(sql, val)
            connection.commit()
        except Exception as e:
            print (e)
    else:
        print("Connection lost")
    
    return 0


def modify_person(Name,Surname,Address,Balance,Username,Password,Admin,Picture):
    connection=creationConnection()

    #Creation cursor
    connection_curseur=connection.cursor()
    
    if (connection.is_connected()):
        try:
            sql = "UPDATE people SET Name=%s, Surname=%s, Address=%s, Balance=%s, Password=%s, Admin=%s, Picture=%s WHERE Username=%s"
            val = (Name,Surname,Address,Balance,Password,Admin,Picture,Username,)
            connection_curseur.execute(sql, val)
            connection.commit()
                    
        except Exception as e:
            print (e)
    else:
        print("Connection lost")


def delete_person(Username):
    connection=creationConnection()

    #Creation cursor
    connection_curseur=connection.cursor()
    
    if (connection.is_connected()):
        try:
            sql = "DELETE FROM people WHERE Username=%s"
            val = (Username,)
            connection_curseur.execute(sql, val)
            connection.commit()
                    
        except Exception as e:
            print (e)
    else:
        print("Connection lost")
        
def select_people():
    connection=creationConnection()

    #Creation cursor
    connection_curseur=connection.cursor()
    
    L=list()
    
    if (connection.is_connected()):
        try:
            sql = "SELECT Username FROM people ORDER BY Username"
            connection_curseur.execute(sql)
            results=connection_curseur.fetchall()
                    
        except Exception as e:
            print (e)
    else:
        print("Connection lost")
    if len(results)!=0:
        for i in results:
            L.append(i[0])
    return L


def get_person_info(Username):
    connection=creationConnection()

    #Creation cursor
    connection_curseur=connection.cursor()
    
    if (connection.is_connected()):
        try:
            sql = "SELECT * FROM people WHERE Username = %s"
            val = (Username,)
            connection_curseur.execute(sql, val)
            results=connection_curseur.fetchall()
                    
        except Exception as e:
            print (e)
    else:
        print("Connection lost")
            
    return results[0]


def deposit(Username,Money):
    connection=creationConnection()
    

    #Creation cursor
    connection_curseur=connection.cursor()
    
    if (connection.is_connected()):
        try:
            sql = "INSERT INTO `deposit` (`Username`, `Money`, `Date`) VALUES (%s,%s,%s)"
            val = (Username,Money,date.today(),)
            connection_curseur.execute(sql, val)
            connection.commit()
        except Exception as e:
            print (e)
    else:
        print("Connection lost")
    return

def pdf_deposits():
    connection=creationConnection()

    #Creation cursor
    connection_curseur=connection.cursor()
    
    if (connection.is_connected()):
        try:
            sql = "SELECT * FROM deposit"
            connection_curseur.execute(sql)
            results=connection_curseur.fetchall()
                    
        except Exception as e:
            print (e)
    else:
        print("Connection lost")
            
    return results


def pdf_sum_deposits():
    connection=creationConnection()

    #Creation cursor
    connection_curseur=connection.cursor()
    
    if (connection.is_connected()):
        try:
            sql = "SELECT SUM(Money) FROM deposit"
            connection_curseur.execute(sql)
            results=connection_curseur.fetchall()
                    
        except Exception as e:
            print (e)
    else:
        print("Connection lost")
            
    return str(results[0][0])


def admin(Username):
    connection=creationConnection()

    #Creation cursor
    connection_curseur=connection.cursor()
    
    if (connection.is_connected()):
        try:
            sql = "SELECT Admin FROM people WHERE Username = %s"
            val = (Username,)
            connection_curseur.execute(sql, val)
            results=connection_curseur.fetchall()
                    
        except Exception as e:
            print (e)
    else:
        print("Connection lost")
    
    if str(results)!=0:
        return (results[0][0]) 
    else:
        return -1
            
def not_flying(Username):
    connection=creationConnection()

    #Creation cursor
    connection_curseur=connection.cursor()
    
    if (connection.is_connected()):
        try:
            sql = "SELECT Username FROM flying WHERE Username = %s"
            val = (Username,)
            connection_curseur.execute(sql, val)
            results=connection_curseur.fetchall()
                    
        except Exception as e:
            print (e)
    else:
        print("Connection lost")
           
    return len(results)


def user_using_this_plane(Username,plane):
    connection=creationConnection()

    #Creation cursor
    connection_curseur=connection.cursor()
    
    if (connection.is_connected()):
        try:
            sql = "SELECT Username FROM flying WHERE Username = %s AND Plane= %s"
            val = (Username,plane,)
            connection_curseur.execute(sql, val)
            results=connection_curseur.fetchall()
                    
        except Exception as e:
            print (e)
    else:
        print("Connection lost")
           
    return len(results)


def pay(Plane,Username,Price,time):
    connection=creationConnection()

    #Creation cursor
    connection_curseur=connection.cursor()
    
    if (connection.is_connected()):
        try:
            sql = "INSERT INTO `flights` (`Plane`, `Username`, `Price`, `Time`, `Date`) VALUES (%s,%s,%s,%s,%s)"
            val = (Plane,Username,Price,time,date.today(),)
            connection_curseur.execute(sql, val)
            connection.commit()
        except Exception as e:
            print (e)
    else:
        print("Connection lost")
        
    return



def initial_contribution(Username):
    connection=creationConnection()

    #Creation cursor
    connection_curseur=connection.cursor()
    
    if (connection.is_connected()):
        try:
            sql = "SELECT Balance FROM people WHERE Username = %s"
            val = (Username,)
            connection_curseur.execute(sql, val)
            results=connection_curseur.fetchall()
                    
        except Exception as e:
            print (e)
    else:
        print("Connection lost")
            
    return str(results[0][0])



def write_deposits_User(Username):
    connection=creationConnection()

    #Creation cursor
    connection_curseur=connection.cursor()
    
    if (connection.is_connected()):
        try:
            sql = "SELECT * FROM deposit WHERE Username = %s"
            val = (Username,)
            connection_curseur.execute(sql, val)
            results=connection_curseur.fetchall()
                    
        except Exception as e:
            print (e)
    else:
        print("Connection lost")
            
    return results







