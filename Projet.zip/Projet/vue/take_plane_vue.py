import  tkinter as tk 
from PIL import ImageTk,Image


class take_plane_vue(tk.Frame):

    def __init__(self, master):
        tk.Frame.__init__(self, master)
        tk.Frame.configure(self,bg='blue')
        tk.Label(self, text="Page one", font=('Helvetica', 18, "bold")).pack(side="top", fill="x", pady=5)
      #  tk.Button(self, text="Go back to start page",
             #     command=lambda: master.switch_frame(log_vue)).pack()


class history_vue(tk.Frame):

    def __init__(self, master):
        tk.Frame.__init__(self, master)
        tk.Frame.configure(self,bg='blue')
        tk.Label(self, text="Page one", font=('Helvetica', 18, "bold")).pack(side="top", fill="x", pady=5)
       # tk.Button(self, text="Go back to start page",
            #      command=lambda: master.switch_frame(log_vue)).pack()
        
class solde_report_vue(tk.Frame):

    def __init__(self, master):
        tk.Frame.__init__(self, master)
        tk.Frame.configure(self,bg='blue')
        tk.Label(self, text="Page one", font=('Helvetica', 18, "bold")).pack(side="top", fill="x", pady=5)
      #  tk.Button(self, text="Go back to start page",
              #    command=lambda: master.switch_frame(log_vue)).pack()