import  tkinter as tk 
from PIL import ImageTk,Image
from vue import manage_planes_vue
from vue import manage_people_vue
from controller import controller_manage_balance_vue

class manage_balance_vue(tk.Frame):

    def __init__(self, master):
        tk.Frame.__init__(self, master)
        tk.Frame.configure(self)
        
        #Menu Options admin
        FrameOptions = tk.Frame(self, borderwidth=2, relief=tk.GROOVE)
        FrameOptions.grid(column=0, row=0, sticky=tk.NW+tk.S)
                
        # Creating a photoimage object to use image 
        img_plane=ImageTk.PhotoImage(Image.open("./res/logo_plane.png"))
        img_person=ImageTk.PhotoImage(Image.open("./res/logo_person.png"))
        img_bilan=ImageTk.PhotoImage(Image.open("./res/logo_bilan.png"))
                                      
        # Button plane
        Button_plane=tk.Button(FrameOptions, text = 'Click Me !', image = img_plane,command=lambda: master.switch_frame(manage_planes_vue.manage_planes_vue))
        Button_plane.image = img_plane
        Button_plane.grid(sticky=tk.NW+tk.S)
        
        # Button person
        Button_person=tk.Button(FrameOptions, text = 'Click Me !', image = img_person,command=lambda: master.switch_frame(manage_people_vue.manage_people_vue))
        Button_person.image = img_person
        Button_person.grid(sticky=tk.NW+tk.S)
        
        # Button bilan
        Button_bilan=tk.Button(FrameOptions, text = 'Click Me !', image = img_bilan)
        Button_bilan.image = img_bilan
        Button_bilan.grid(sticky=tk.NW+tk.S)
        
        #Main Frame
        FramePrincipal = tk.Frame(self, borderwidth=2, relief=tk.GROOVE)
        FramePrincipal.grid(column=1, row=0,  sticky=tk.NE)
        
        
        #Give money
        MoneyPerson = tk.PanedWindow(FramePrincipal, orient=tk.HORIZONTAL)

        
        self.valueMoneyUsername = tk.StringVar() 
        self.valueMoneyUsername.set("Username")
        self.entryMoneyUsername = tk.Entry(MoneyPerson, textvariable=self.valueMoneyUsername, width=20)
        
        self.valueBalance = tk.IntVar()
        self.entryBalance = tk.Spinbox(MoneyPerson, from_=-10000,to=10000, width=10,textvariable=self.valueBalance)
        
        Button_MoneyValidate=tk.Button(MoneyPerson, text = 'Add money', command=self.money_person)

        MoneyPerson.add(tk.Label(MoneyPerson, text='Add money:',  anchor=tk.CENTER, width=20))
        MoneyPerson.add(self.entryMoneyUsername)
        MoneyPerson.add(self.entryBalance)
        MoneyPerson.add(Button_MoneyValidate)
        MoneyPerson.pack()
        
        #Money Overhaul
        MoneyOverhaul = tk.PanedWindow(FramePrincipal, orient=tk.HORIZONTAL)

        
        self.valueMoneyPlane = tk.StringVar() 
        self.valueMoneyPlane.set("Immatriculation")
        self.entryMoneyPlane = tk.Entry(MoneyOverhaul, textvariable=self.valueMoneyPlane, width=20)
        
        self.valueMoneyOverhaul = tk.IntVar()
        self.entryMoneyOverhaul = tk.Spinbox(MoneyOverhaul, from_=-10000,to=10000, width=10,textvariable=self.valueMoneyOverhaul)
        
        Button_OverhaulValidate=tk.Button(MoneyOverhaul, text = 'Add money', command=self.money_overhaul)

        MoneyOverhaul.add(tk.Label(MoneyOverhaul, text='Money Overhaul:',  anchor=tk.CENTER, width=20))
        MoneyOverhaul.add(self.entryMoneyPlane)
        MoneyOverhaul.add(self.entryMoneyOverhaul)
        MoneyOverhaul.add(Button_OverhaulValidate)
        MoneyOverhaul.pack()
        
        
    def money_person(self):
        controller_manage_balance_vue.money_person(self.valueMoneyUsername.get(),self.valueBalance.get())
        return
    
    def money_overhaul(self):
        controller_manage_balance_vue.money_overhaul(self.valueMoneyPlane.get(),self.valueMoneyOverhaul.get())
        return
        
        
        
        