import  tkinter as tk 
from PIL import ImageTk,Image
from vue import manage_planes_vue
from vue import manage_people_vue

class manage_balance_vue(tk.Frame):

    def __init__(self, master):
        tk.Frame.__init__(self, master)
        tk.Frame.configure(self)
        
        #Menu Options admin
        FrameOptions = tk.Frame(self, borderwidth=2, relief=tk.GROOVE)
        FrameOptions.grid(column=0, row=0, sticky=tk.NW+tk.S)
                
        # Creating a photoimage object to use image 
        img_plane=ImageTk.PhotoImage(Image.open("./res/logo_plane.png"))
        img_person=ImageTk.PhotoImage(Image.open("./res/logo_person.png"))
        img_bilan=ImageTk.PhotoImage(Image.open("./res/logo_bilan.png"))
                                      
        # Button plane
        Button_plane=tk.Button(FrameOptions, text = 'Click Me !', image = img_plane,command=lambda: master.switch_frame(manage_planes_vue.manage_planes_vue))
        Button_plane.image = img_plane
        Button_plane.grid(sticky=tk.NW+tk.S)
        
        # Button person
        Button_person=tk.Button(FrameOptions, text = 'Click Me !', image = img_person,command=lambda: master.switch_frame(manage_people_vue.manage_people_vue))
        Button_person.image = img_person
        Button_person.grid(sticky=tk.NW+tk.S)
        
        # Button bilan
        Button_bilan=tk.Button(FrameOptions, text = 'Click Me !', image = img_bilan)
        Button_bilan.image = img_bilan
        Button_bilan.grid(sticky=tk.NW+tk.S)
        
        #Main Frame
        FramePrincipal = tk.Frame(self, borderwidth=2, relief=tk.GROOVE)
        FramePrincipal.grid(column=1, row=0,  sticky=tk.NE)
        
        