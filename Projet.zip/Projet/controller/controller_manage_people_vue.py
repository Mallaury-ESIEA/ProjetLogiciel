from PIL import Image
from tkinter.messagebox import *
from model import data_base_people
import os


def transform_Picture(Username,Picture):
    link='./res/people/'+Username+'.png'
    
    x = 200 # largeur
    y = 200 # hauteur
    img = Image.open(Picture, 'r').resize((x,y)).save(link)
    
    return link

def controllEntries(Name,Surname,Address,Balance,Username,Password,Admin,Picture):
    if len(Name)==0 or len(Surname)==0 or len(Address)==0 or len(Username)==0 or len(Password)==0 or len(Picture)==0:
        showinfo('New Person', 'Incomplete')
        return
    if(data_base_people.person_not_exists(Username)==0):
        showinfo('New Person', 'This Username already exists')
        return
    
    Picture=transform_Picture(Username,Picture)
    data_base_people.insert_new_person(Name,Surname,Address,Balance,Username,Password,Admin,Picture)
    showinfo('New Person', 'The person has been created')
    return

def modifyPerson(Name,Surname,Address,Balance,Username,Password,Admin,Picture):
    if len(Name)==0 or len(Surname)==0 or len(Address)==0 or len(Username)==0 or len(Password)==0 or len(Picture)==0:
        showinfo('Modify Person', 'Incomplete')
        return
    if(data_base_people.person_not_exists(Username)==1):
        showinfo('Modify Person', 'This Username does not exist')
        return
    Picture=transform_Picture(Username,Picture)
    data_base_people.modify_person(Name,Surname,Address,Balance,Username,Password,Admin,Picture)
    showinfo('Modify Person', 'The username has been modified')
    return


def delete_person(Username):
    if len(Username)==0:
        showinfo('Delete Person', 'Incomplete')
        return
    if(data_base_people.person_not_exists(Username)==1):
        showinfo('New Person', 'This person does not exist')
        return
    data_base_people.delete_person(Username)
    delete_picture(Username)
    showinfo('New Plane', 'The person has been deleted')
    return

def delete_picture(Username):
    link='./res/people/'+Username+'.png'
    
    if os.path.exists(link):
        os.remove(link)
    else:
        print("No picture")
    return

def build_list():
    return data_base_people.select_people()

def get_person_info(Username):
    return data_base_people.get_person_info(Username)