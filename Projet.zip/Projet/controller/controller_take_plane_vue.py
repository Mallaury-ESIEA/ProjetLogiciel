from tkinter.messagebox import *

from model import data_base_planes
from model import data_base_people

def is_possible(Username,Plane):
    if Plane=='':
        showinfo('Rent a plane', 'Choose a plane')
        return 0
        
    if data_base_planes.not_flying(Plane)==0:
        if data_base_people.not_flying(Username)==0:
            return 1
        else:
            showinfo('Rent a plane', Username+' has already a rental')
            return 0
    else:
        showinfo('Rent a plane', Plane+' is already flying')
        return 0
    
def rent_plane(Username,plane):
    data_base_planes.rent_plane(Username,plane)
    showinfo('Rent a plane', 'You are renting '+plane)
    return

def calculatePrice(Plane,time):
    if Plane=='':
        showinfo('Return a plane', 'Select a plane')
        return 0
    
    if time>0 and time< 1000000:
        var_Price=data_base_planes.plane_price(Plane)*time/60
        return "%.2f" %var_Price
    
    return 0
    

def user_using_this_plane(Username,plane):
    if data_base_people.user_using_this_plane(Username,plane):
        return 1
    showinfo('Return a plane', 'You didn''t rent this plane')
    return 0

def return_plane(Username,Plane,time):
    #Insert in flights
    data_base_people.pay(Plane,Username,calculatePrice(Plane,time),time)
    
    #return plane
    data_base_planes.return_plane(Plane,Username)
    
    showinfo('Return a plane', 'You have returned '+Plane)
    
    return