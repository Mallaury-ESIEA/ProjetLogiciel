from reportlab.pdfgen import canvas
from reportlab.lib.units import cm
from tkinter.messagebox import *

from model import data_base_planes
from model import data_base_people

def fill_pilot_logbook(pdf,Username):
    
    #Flights
    a=[21.5,0,0,0]
    
    pdf.setFont('Helvetica', 16)
    pdf.drawString(3*cm, 23*cm, u'Flights')
    
    
    L=data_base_planes.get_flights(Username)
    
    pdf.setFont('Helvetica', 12)
    for i in L:
        String=str(i[4])+'   Plane: '+i[0]+'  for: '+str(int(i[3]/60))+'h '+str(i[3]%60)+'min  '+' costed: '+str(i[2])+' €'
        pdf.drawString(3*cm, a[0]*cm, u''+String+'')
        a[0]=a[0]-1.5
        
        a[1]+=1
        a[2]+=i[2]
        a[3]+=i[3]
        
        
        if(a[0]<3):
            pdf.showPage()
            a[0]=25
    
    
    if(a[0]<10):
        pdf.showPage()
        a[0]=25
    
    pdf.line(3*cm,a[0]*cm,18*cm,a[0]*cm)
    a[0]=a[0]-1.5
    
       
    pdf.drawString(10*cm, a[0]*cm, u'Total: '+ str(a[1])+' flights  '+str(int(a[3]/60))+'h '+str(a[3]%60)+'min  '+str(a[2])+' €')
       
    
    return pdf

def info_Logbook_created():
    showinfo('Pilot logbook', 'Created')    
    return

def info_Balance_created():
    showinfo('Account_balance_', 'Created')    
    return


def fill_account_balance(pdf,Username):
    
    pdf=initial_contribution(pdf,Username)
    pdf.showPage()
    pdf=fill_pilot_logbook(pdf,Username)
    pdf.showPage()
    pdf=write_deposits_User(pdf,Username)
    pdf.showPage()
    pdf=total_balance(pdf,Username)    
    
    info_Balance_created()
    
    return pdf



def initial_contribution(pdf,Username):
    
    #Initial contribution
    a=[21.5,0,0,0]
    L=data_base_people.initial_contribution(Username)
    
    pdf.setFont('Helvetica', 16)
    
    String='Initial contribution: '+str(L)
    pdf.drawString(3*cm, a[0]*cm, u''+String+'')
        
    return pdf




def write_deposits_User(pdf,Username):
    
    #Flights
    a=[21.5,0,0,0]
    
    pdf.setFont('Helvetica', 16)
    pdf.drawString(3*cm, 23*cm, u'Deposits')
    
    
    L=data_base_people.pdf_deposits()
    
    pdf.setFont('Helvetica', 12)
    for i in L:
        String=str(i[2])+' '+str(i[1])+'€'
        pdf.drawString(3*cm, a[0]*cm, u''+String+'')
        a[0]=a[0]-1.5

        if(a[0]<3):
            pdf.showPage()
            a[0]=25
    
    
    pdf.line(3*cm,a[0]*cm,18*cm,a[0]*cm)
    a[0]=a[0]-1.5
    
    if(a[0]<3):
        pdf.showPage()
        a[0]=25
    
    pdf.setFont('Helvetica', 16)
    L=data_base_people.pdf_sum_deposits()
    if(L=='None'):
        L=0
    a[1]=L    
    pdf.drawString(10*cm, a[0]*cm, u'Sum of deposits: '+str(L)+' €')
    a[0]=a[0]-1.5

    if(a[0]<3):
        pdf.showPage()
        a[0]=25
    
    pdf.line(3*cm,a[0]*cm,18*cm,a[0]*cm)
    a[0]=a[0]-1.5
    
    if(a[0]<3):
        pdf.showPage()
        a[0]=25
    
    return pdf



def total_balance(pdf,Username):

    initial_contribution=data_base_people.initial_contribution(Username)
    
    total_deposits=0.0
    deposits=data_base_people.pdf_deposits()
    for i in deposits:
        total_deposits=total_deposits+i[1]
    
    total_flights=0.0
    flights=data_base_planes.get_flights(Username)
    for i in flights:
        total_flights=total_flights+i[2]
    
    
    
    pdf.setFont('Helvetica', 18)
    pdf.drawString(10*cm, 23*cm, u'Total balance: '+str(float(initial_contribution)-total_flights+total_deposits)+' €')
    
    return pdf

