from reportlab.pdfgen import canvas
from reportlab.lib.units import cm
from tkinter.messagebox import *

from model import data_base_planes

def fill_pilot_logbook(pdf,Username):
    
    #Flights
    a=[21.5,0,0,0]
    
    pdf.setFont('Helvetica', 16)
    pdf.drawString(3*cm, 23*cm, u'Flights')
    
    
    L=data_base_planes.get_flights(Username)
    
    pdf.setFont('Helvetica', 12)
    for i in L:
        String=str(i[4])+'   Plane: '+i[0]+'  for: '+str(int(i[3]/60))+'h '+str(i[3]%60)+'min  '+' costed: '+str(i[2])+' €'
        pdf.drawString(3*cm, a[0]*cm, u''+String+'')
        a[0]=a[0]-1.5
        
        a[1]+=1
        a[2]+=i[2]
        a[3]+=i[3]
        
        
        if(a[0]<3):
            pdf.showPage()
            a[0]=25
    
    
    if(a[0]<10):
        pdf.showPage()
        a[0]=25
    
    pdf.line(3*cm,a[0]*cm,18*cm,a[0]*cm)
    a[0]=a[0]-1.5
    
       
    pdf.drawString(10*cm, a[0]*cm, u'Total: '+ str(a[1])+' flights  '+str(int(a[3]/60))+'h '+str(a[3]%60)+'min  '+str(a[2])+' €')
       
    
    showinfo('Pilot logbook', 'Created')
    return pdf

def fill_account_balance(pdf,Username):
    return pdf