from tkinter.messagebox import *
from model import data_base_planes

def controllEntries(login,password):
    if len(login) == 0 or len(password) == 0:
        showinfo('Credentials', 'Crdentials incorrects')
        return 0
    if data_base_planes.credentials_corrects(login, password) == 0:
        return 0
    return 1
