from tkinter.messagebox import *
from model import data_base_planes
from model import data_base_people

def controllEntries(login,password):
    if len(login) == 0 or len(password) == 0:
        showinfo('Credentials', 'Crdentials incorrects')
        return 0
    if data_base_planes.credentials_corrects(login, password) == 0:
        return 0
    return 1

def admin(login):
    return data_base_people.admin(login)