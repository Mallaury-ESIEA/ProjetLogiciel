from tkinter.messagebox import *
from model import data_base_people
from model import data_base_planes


def money_person(Username,Money):
    if len(Username)==0 or Money==0:
        showinfo('Add money', 'Incomplete')
        return
    if(data_base_people.person_not_exists(Username)==1):
        showinfo('Add money', 'This Username does not exist')
        return
    data_base_people.deposit(Username,Money)
    showinfo('Add money', 'Deposit done')
    return

def money_overhaul(Plane,Money):
    if len(Plane)==0 or Money==0:
        showinfo('Add overhaul', 'Incomplete')
        return
    if(data_base_planes.immatriculaton_not_exists(Plane)==1):
        showinfo('Add overhaul', 'This plane does not exist')
        return
    data_base_planes.overhaul(Plane,Money)
    showinfo('Add overhaul', 'Overhaul added')
    return