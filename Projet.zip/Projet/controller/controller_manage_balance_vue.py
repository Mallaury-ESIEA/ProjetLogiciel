from tkinter.messagebox import *
from model import data_base_people
from model import data_base_planes

from reportlab.pdfgen import canvas
from reportlab.lib.units import cm


def money_person(Username,Money):
    if len(Username)==0 or Money==0:
        showinfo('Add money', 'Incomplete')
        return
    if(data_base_people.person_not_exists(Username)==1):
        showinfo('Add money', 'This Username does not exist')
        return
    data_base_people.deposit(Username,Money)
    showinfo('Add money', 'Deposit done')
    return

def money_overhaul(Plane,Money):
    if len(Plane)==0 or Money==0:
        showinfo('Add overhaul', 'Incomplete')
        return
    if(data_base_planes.immatriculaton_not_exists(Plane)==1):
        showinfo('Add overhaul', 'This plane does not exist')
        return
    data_base_planes.overhaul(Plane,Money)
    showinfo('Add overhaul', 'Overhaul added')
    return


def fill_pdf(pdf):
    pdf.drawString(3*cm, 25*cm, u'Financial report')
    pdf.line(3*cm,24.5*cm,18*cm,24.5*cm)
    #Deposits
    a=[21.5,0,0,0]
    #deposits
    pdf=fill_pdf_deposits(pdf,a)
    #Flights
    pdf=fill_pdf_flights(pdf,a)
    #overhauls
    pdf=fill_pdf_overhauls(pdf,a)
    #total
    pdf=fill_pdf_total(pdf,a)
    #End
    showinfo('Financial report', 'Created')
    return pdf

def fill_pdf_deposits(pdf,a):
    pdf.drawString(3*cm, 23*cm, u'Deposits')
    
    
    L=data_base_people.pdf_deposits()
    
    for i in L:
        String='M/Mmme: '+i[0]+' '+str(i[1])+'€'
        pdf.drawString(3*cm, a[0]*cm, u''+String+'')
        a[0]=a[0]-1.5

        if(a[0]<3):
            pdf.showPage()
            a[0]=25
    
    
    pdf.line(3*cm,a[0]*cm,18*cm,a[0]*cm)
    a[0]=a[0]-1.5
    
    if(a[0]<3):
        pdf.showPage()
        a[0]=25
    
    
    L=data_base_people.pdf_sum_deposits()
    if(L=='None'):
        L=0
    a[1]=L    
    pdf.drawString(10*cm, a[0]*cm, u'Sum of deposits: '+str(L)+' €')
    a[0]=a[0]-1.5

    if(a[0]<3):
        pdf.showPage()
        a[0]=25
    
    pdf.line(3*cm,a[0]*cm,18*cm,a[0]*cm)
    a[0]=a[0]-1.5
    
    if(a[0]<3):
        pdf.showPage()
        a[0]=25
    
    return pdf


def fill_pdf_flights(pdf,a):
    pdf.showPage()
    pdf.drawString(3*cm, 23*cm, u'Flights')
    a[0]=21.5
    
    L=data_base_planes.pdf_flights()
    
    for i in L:
        String='M/Mmme: '+i[1]+' '+str(i[2])+'€'+' Plane: '+i[0]
        pdf.drawString(3*cm, a[0]*cm, u''+String+'')
        a[0]=a[0]-1.5

        if(a[0]<3):
            pdf.showPage()
            a[0]=25
    
    
    pdf.line(3*cm,a[0]*cm,18*cm,a[0]*cm)
    a[0]=a[0]-1.5
    
    if(a[0]<3):
        pdf.showPage()
        a[0]=25
    
    
    L=data_base_planes.pdf_sum_flights()
    if(L=='None'):
        L=0
    a[2]=L    
    pdf.drawString(10*cm, a[0]*cm, u'Sum of flights: '+str(L)+' €')
    a[0]=a[0]-1.5

    if(a[0]<3):
        pdf.showPage()
        a[0]=25
    
    pdf.line(3*cm,a[0]*cm,18*cm,a[0]*cm)
    a[0]=a[0]-1.5
    
    if(a[0]<3):
        pdf.showPage()
        a[0]=25
    
    return pdf


def fill_pdf_overhauls(pdf,a):
    pdf.showPage()
    pdf.drawString(3*cm, 23*cm, u'Overhauls')
    a[0]=21.5
    
    L=data_base_planes.pdf_overhauls()
    
    for i in L:
        String='Plane: '+i[0]+' '+str(i[1])+'€'
        pdf.drawString(3*cm, a[0]*cm, u''+String+'')
        a[0]=a[0]-1.5

        if(a[0]<3):
            pdf.showPage()
            a[0]=25
    
    
    pdf.line(3*cm,a[0]*cm,18*cm,a[0]*cm)
    a[0]=a[0]-1.5
    
    if(a[0]<3):
        pdf.showPage()
        a[0]=25
    
    
    L=data_base_planes.pdf_sum_overhauls()
    if(L=='None'):
        L=0
    a[3]=L    
    pdf.drawString(10*cm, a[0]*cm, u'Sum of overhauls: '+str(L)+' €')
    a[0]=a[0]-1.5

    if(a[0]<3):
        pdf.showPage()
        a[0]=25
    
    pdf.line(3*cm,a[0]*cm,18*cm,a[0]*cm)
    a[0]=a[0]-1.5
    
    if(a[0]<3):
        pdf.showPage()
        a[0]=25
    
    return pdf



def fill_pdf_total(pdf,a):
    String=str(float(a[1])-float(a[2])-float(a[3]))
    pdf.drawString(12*cm, a[0]*cm, u'Total:'+String+' €')
    return pdf


