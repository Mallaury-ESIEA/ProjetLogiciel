from tkinter.messagebox import *
import  tkinter as tk 
from model import data_base_planes
from PIL import Image
from PIL import ImageTk
import os

def controllEntries(Immatriculation,Model,Year,Hours,Price,Overhaul,Picture,Flying):
    if len(Immatriculation)==0 or len(Model)==0 or len(Picture)==0:
        showinfo('New Plane', 'Incomplete')
        return
    if(data_base_planes.immatriculaton_not_exists(Immatriculation)==0):
        showinfo('New Plane', 'This plane already exists')
        return
    Picture=transform_Picture(Immatriculation,Picture)
    data_base_planes.insert_new_plane(Immatriculation,Model,Year,Hours,Price,Overhaul,Picture,Flying)
    showinfo('New Plane', 'The plane has been created')
    return

def transform_Picture(Immatriculation,Picture):
    link='./res/planes/'+Immatriculation+'.png'
    
    x = 200 # largeur
    y = 200 # hauteur
    img = Image.open(Picture, 'r').resize((x,y)).save(link)
    
    return link

def modifyPlane(Immatriculation,Model,Year,Hours,Price,Overhaul,Picture,Flying):
    if len(Immatriculation)==0 or len(Model)==0 or len(Picture)==0:
        showinfo('New Plane', 'Incomplete')
        return
    if(data_base_planes.immatriculaton_not_exists(Immatriculation)==1):
        showinfo('New Plane', 'This plane does not exist')
        return
    Picture=transform_Picture(Immatriculation,Picture)
    data_base_planes.modify_plane(Immatriculation,Model,Year,Hours,Price,Overhaul,Picture,Flying)
    showinfo('New Plane', 'The plane has been modified')
    return    

def delete_plane(Immatriculation):
    if len(Immatriculation)==0:
        showinfo('New Plane', 'Incomplete')
        return
    if(data_base_planes.immatriculaton_not_exists(Immatriculation)==1):
        showinfo('New Plane', 'This plane does not exist')
        return
    data_base_planes.delete_plane(Immatriculation)
    delete_picture(Immatriculation)
    showinfo('New Plane', 'The plane has been deleted')
    return

def delete_picture(Immatriculation):
    link='./res/planes/'+Immatriculation+'.png'
    
    if os.path.exists(link):
        os.remove(link)
    else:
        print("No picture")
    return

def build_list():
    return data_base_planes.select_all_immatriculation()

def get_plane_info(plane):
    return data_base_planes.get_plane_info(plane)

